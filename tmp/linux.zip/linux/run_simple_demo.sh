./SemiFinalJudge ./Demo/main -m ./maps/map1.txt
